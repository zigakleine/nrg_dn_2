﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PathTracer.Samplers;

namespace PathTracer
{
  class PathTracer
  {
    public Spectrum Li(Ray r, Scene s)
    {
      var L = Spectrum.ZeroSpectrum;
      /* Implement */
      return L;
    }

  }
}
